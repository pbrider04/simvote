# simvote
Simple feedback tool for questions and descriptions, that can be voted for.

It is built with Python Flask + SQLite.

## Features
- Submit a question + description + name
- View and vote on feedback
- No login required

## Run locally with Docker
```bash
docker-compose up --build
```